# TrajCert publication sources

Main document: main.tex. Supplement: supplementary/supplement.tex.
Build both from the archive root, using a TeX distribution with latexmk,
elsarticle, natbib, the standard packages declared in preamble.tex, and BibTeX:

    latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main.tex
    latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build supplementary/supplement.tex

All figure PDFs, table inputs and bibliography sources are included. main.bbl
is supplied for submission systems that request a compiled bibliography.
Scientific simulations are not needed to compile the documents. The numerical
supporting records are supplied separately in evidence_current.zip; its manifest
identifies unchanged source payloads. Third-party reference PDFs and internal
preparation audits are not submission material and are excluded.

The manuscript uses elsarticle as its existing preprint renderer without naming
a target journal. The theorem states conditional numerical hypotheses; the
current fast confidence-sign filter lacks a uniform error derivation in the
available evidence. Historical source identity is also not fully attested.
Author approval was confirmed by the user on 22 October 2026. Journal-specific
submission requirements remain to be checked after venue selection.
